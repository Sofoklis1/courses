package org.afdemp.bootcamp2.lesson4.examples.controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.afdemp.bootcamp2.lesson4.examples.dao.EmployeeDAO;
import org.afdemp.bootcamp2.lesson4.examples.model.Employee;

/**
 * Servlet implementation class SearchController
 */
@WebServlet("/searchresults")
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		/*
		 * In this example, we want to accept requests only from the form (SearchEmploeeForm Servlet).
		 * Thus, any get request is redirected to the form.
		 */
		response.sendRedirect("search.jsp");		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/* 
		 * In case user typed surname in Greek (or other language), we override the name of the character encoding used in the body of this request.
		 * Because, If a character encoding is not specified, the Servlet specification requires that an encoding of ISO-8859-1 is used.
		 * It method must be called prior to reading request parameters. Otherwise, it has no effect.  
		 */
		request.setCharacterEncoding("UTF-8");
		
		/*
		 * Read surname parameter from the request object. 
		 */
		String surname = request.getParameter("surname");
		
		//Get RequestDispatcher from request object
		RequestDispatcher rd = request.getRequestDispatcher("/search.jsp");
		
		/*
		 * Perform some data validation (Surname should not be null and at least 2 characters long).
		 * If data is not valid, then we forward the request to ErrorPrinter Servlet with a message (by adding an attribute in request object)
		 */
		if( surname == null || surname.length() < 2 ) {
						
			//add attribute to request object (a String with the error message)
			request.setAttribute("message", "Το πεδίο <b>Επώνυμο</b> θα πρέπει να αποτελείται από τουλάχιστον 2 χαρακτήρες");
			//forward back to SearchEmploeeForm (/search) with the error message (attribute)
			rd.forward(request, response);
			return;
		}
		
		/*
		 * If the data is valid, then we will get the list of employees and forward it to the ViewSearchResults Servlet to print the results. 
		 */
		
		//Get again RequestDispatcher from request object
		RequestDispatcher rd2 = request.getRequestDispatcher("/viewresults.jsp");
		
		EmployeeDAO edao = new EmployeeDAO();
		ArrayList<Employee> resultlist = null;
		
		try {
			
			resultlist = edao.findEmployeeBySurname(surname);
			
		} catch (Exception e) {
			
			request.setAttribute("message", "<b>Σφάλμα</b><br>" + e.getMessage());
			
			rd.forward(request, response);
			return;
			
		}
		
		
		
		//add attribute to request object (an ArrayList of Employee objects)
		request.setAttribute("employee-list", resultlist);
		
		rd2.forward(request, response);
		return;
		
	}

}
