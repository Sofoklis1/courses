package org.afdemp.bootcamp2.lesson3.project.dao;

import org.afdemp.bootcamp2.lesson3.project.connection.DB;
import org.afdemp.bootcamp2.lesson3.project.model.Customer;

import java.util.ArrayList;
import java.sql.*;

public class CustomerDAO {

	public CustomerDAO() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<Customer> getCustomers() throws Exception {

		/*
		 * The method should return an ArrayList of Customer objects, acquired
		 * from database via query
		 */

	}

	public void saveCustomer(Customer customer) throws Exception {

		/* The method should insert Customer data to database */

	}

}
