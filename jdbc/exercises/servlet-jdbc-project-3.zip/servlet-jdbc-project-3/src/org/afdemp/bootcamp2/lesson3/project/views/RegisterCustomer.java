package org.afdemp.bootcamp2.lesson3.project.views;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.afdemp.bootcamp2.lesson3.project.model.Customer;

/**
 * Servlet implementation class RegisterCustomer
 */
@WebServlet("/createcustomerdone")
public class RegisterCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = new PrintWriter(response.getWriter());
		
		Customer customer = (Customer)request.getAttribute("newcustomer");
		
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("    <head>");
		out.println("        <meta charset='utf-8'>");
		out.println("        <meta http-equiv='X-UA-Compatible' content='IE=edge'>");
		out.println("        <meta name='viewport' content='width=device-width, initial-scale=1'>");
		out.println("        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->");
		out.println("");
		out.println("        <title>Register New Customer</title>");
		out.println("");
		out.println("        <!-- Bootstrap core CSS -->");
		out.println("        <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
		out.println("        ");
		out.println("        <!-- Optional theme -->");
		out.println("		<!-- <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css'>  -->");
		out.println("       ");
		out.println("        <!-- custom style -->");
		out.println("		<link rel='stylesheet' href='css/mystyle.css'>");
		out.println("");
		out.println("        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->");
		out.println("        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->");
		out.println("        <!--[if lt IE 9]>");
		out.println("          <script src='https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js'></script>");
		out.println("          <script src='https://oss.maxcdn.com/respond/1.4.2/respond.min.js'></script>");
		out.println("        <![endif]-->");
		out.println("    </head>");
		out.println("    <body>");
		out.println("");
		out.println("    <!-- Fixed navbar -->");
		out.println("    <nav class='navbar navbar-inverse navbar-fixed-top'>");
		out.println("      <div class='container'>");
		out.println("        <div class='navbar-header'>");
		out.println("          <button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#navbar' aria-expanded='false' aria-controls='navbar'>");
		out.println("            <span class='sr-only'>Toggle navigation</span>");
		out.println("            <span class='icon-bar'></span>");
		out.println("            <span class='icon-bar'></span>");
		out.println("            <span class='icon-bar'></span>");
		out.println("          </button>");
		out.println("          <a class='navbar-brand' href='#'>LESSON 3</a>");
		out.println("        </div>");
		out.println("        <div id='navbar' class='navbar-collapse collapse'>");
		out.println("          <ul class='nav navbar-nav'>");
		out.println("            <li><a href='new'><span class='glyphicon glyphicon-plus'></span> New Customer</a></li>");
		out.println("            <li><a href='customers'><span class='glyphicon glyphicon-user'></span> Vew Customers</a></li>");
		out.println("          </ul>");
		out.println("        </div><!--/.nav-collapse -->");
		out.println("      </div>");
		out.println("    </nav>");
		
		out.println("      <div class='container'>");
		out.println("			<!-- first row -->");
		out.println("			<div class='row'>");
		out.println("				<div class='col-xs-12'>");
		out.println("					<div class='page-header'>");
		out.println("					  <h1>Customer Registration <small>Done!</small></h1>");
		out.println("					</div>");
		out.println("				</div>");
		out.println("			</div>");
		out.println("			<!-- second row -->");
		out.println("			<div class='row'>");
		out.println("				<div class='col-xs-12'>");
		out.println("						<div class='alert alert-success'>");
		out.println("							<p class='text-center'>");
		out.println("								The new Customer has been registered successfully!");
		out.println("							</p>");
		out.println("						</div>");
		out.println("				</div>");
		out.println("			</div>");
		out.println("");
		out.println("			<!-- third row -->");
		out.println("			<div class='row'>");
		out.println("				<div class='col-xs-12'>");
		out.println("					<div class='table-responsive'>");
		out.println("					  <table id='product-details' class='table table-bordered table-hover table-condensed'>");
		out.println("						<tr>");
		out.println("							<th>Name:</th>");
		out.println("							<td>" + customer.getName() + "</td>");
		out.println("						</tr>");
		out.println("						<tr>");
		out.println("							<th>Surname:</th>");
		out.println("							<td>" + customer.getSurname() + "</td>");
		out.println("						</tr>");
		out.println("						<tr>");
		out.println("							<th>Email:</th>");
		out.println("							<td>" + customer.getEmail() + "</td>");
		out.println("						</tr>");
		out.println("						<tr>");
		out.println("							<th>Phone</th>");
		out.println("							<td>" + customer.getPhone() + "</td>");
		out.println("						</tr>");
		out.println("						");
		out.println("					  </table>");
		out.println("					</div>");
		out.println("				</div>");
		out.println("			</div>");
		out.println("");
		out.println("");
		out.println("		</div><!-- /.container -->");
		out.println("");
		out.println("      <!-- JavaScript files before the closing body tag -->");
		out.println("      <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>");
		out.println("      <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
		out.println("  </body>");
		out.println("</html>");

		
		
	}

}
