package org.afdemp.bootcamp2.lesson3.project.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.afdemp.bootcamp2.lesson3.project.dao.CustomerDAO;
import org.afdemp.bootcamp2.lesson3.project.model.Customer;

/**
 * Servlet implementation class CustomerController
 */
@WebServlet("/savecustomer")
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CustomerController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String name = request.getParameter("name");
		String surname = request.getParameter("surname");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");

		RequestDispatcher successDispatcher = request.getRequestDispatcher("/createcustomerdone");
		RequestDispatcher errorDispatcher = request.getRequestDispatcher("/error");

		if (name == null || name.length() < 2 || surname == null || surname.length() < 2 || email == null
				|| email.length() < 5 || phone == null || phone.length() < 10) {

			request.setAttribute("message", "Customer fields are not valid");

			errorDispatcher.forward(request, response);
			return;

		}

		Customer customer = new Customer(name, surname, email, phone);

		CustomerDAO cdao = new CustomerDAO();

		try {

			cdao.saveCustomer(customer);

			request.setAttribute("newcustomer", customer);

			successDispatcher.forward(request, response);
			return;

		} catch (Exception e) {

			request.setAttribute("message", "<b>Σφάλμα</b><br>" + e.getMessage());

			errorDispatcher.forward(request, response);
			return;

		}

	}

}
