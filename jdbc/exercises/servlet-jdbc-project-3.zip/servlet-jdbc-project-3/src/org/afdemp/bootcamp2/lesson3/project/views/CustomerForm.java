package org.afdemp.bootcamp2.lesson3.project.views;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CustomerForm
 */
@WebServlet("/new")
public class CustomerForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CustomerForm() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = new PrintWriter(response.getWriter());

		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("    <head>");
		out.println("        <meta charset='utf-8'>");
		out.println("        <meta http-equiv='X-UA-Compatible' content='IE=edge'>");
		out.println("        <meta name='viewport' content='width=device-width, initial-scale=1'>");
		out.println("        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->");
		
		out.println("        <title>Register New Customer</title>");
		
		out.println("        <!-- Bootstrap core CSS -->");
		out.println("        <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>");
				
		out.println("        <!-- custom style -->");
		out.println("		<link rel='stylesheet' href='css/mystyle.css'>");
		
		out.println("        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->");
		out.println("        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->");
		out.println("        <!--[if lt IE 9]>");
		out.println("          <script src='https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js'></script>");
		out.println("          <script src='https://oss.maxcdn.com/respond/1.4.2/respond.min.js'></script>");
		out.println("        <![endif]-->");
		out.println("    </head>");
		out.println("    <body>");

		out.println("    <!-- Fixed navbar -->");
		out.println("    <nav class='navbar navbar-inverse navbar-fixed-top'>");
		out.println("      <div class='container'>");
		out.println("        <div class='navbar-header'>");
		out.println("          <button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#navbar' aria-expanded='false' aria-controls='navbar'>");
		out.println("            <span class='sr-only'>Toggle navigation</span>");
		out.println("            <span class='icon-bar'></span>");
		out.println("            <span class='icon-bar'></span>");
		out.println("            <span class='icon-bar'></span>");
		out.println("          </button>");
		out.println("          <a class='navbar-brand' href='#'>LESSON 3</a>");
		out.println("        </div>");
		out.println("        <div id='navbar' class='navbar-collapse collapse'>");
		out.println("          <ul class='nav navbar-nav'>");
		out.println(
				"            <li class='active'><a href='new'><span class='glyphicon glyphicon-plus'></span> New Customer</a></li>");
		out.println(
				"            <li><a href='customers'><span class='glyphicon glyphicon-user'></span> Vew Customers</a></li>");
		out.println("          </ul>");
		out.println("        </div><!--/.nav-collapse -->");
		out.println("      </div>");
		out.println("    </nav>");

		out.println("");
		out.println("      <div class='container'>");
		// out.println(" <h1 class='text-center'>Register New Customer</h1>");
		out.println("      	<div class='page-header'>");
		out.println("        	<h1 class='text-center'>Register New Customer</h1>");
		out.println("       </div>");

		if (request.getAttribute("message") != null) {

			out.println("      	<div class='alert alert-danger'>");
			out.println("			<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>");
			out.println("        	<p class='text-center'>" + (String) request.getAttribute("message") + "</p>");
			out.println("       </div>");

		}

		out.println("        <form action='savecustomer' method='post' class='form-horizontal'>");
		out.println("          <div class='form-group'>");
		out.println("            <label for='name' class='col-sm-2 control-label'>Name:</label>");
		out.println("            <div class='col-sm-10'>");
		out.println(
				"              <input type='text' name='name' id='name' class='form-control' placeholder='Customer Name'>");
		out.println("            </div>");
		out.println("          </div>");
		out.println("                    ");
		out.println("          <div class='form-group'>");
		out.println("            <label for='surname' class='col-sm-2 control-label'>Surname:</label>");
		out.println("            <div class='col-sm-10'>");
		out.println(
				"              <input type='text' name='surname' id='surname' class='form-control' placeholder='Customer Surname'>");
		out.println("            </div>");
		out.println("          </div>");
		out.println("          <div class='form-group'>");
		out.println("            <label for='email' class='col-sm-2 control-label'>Email</label>");
		out.println("            <div class='col-sm-10'>");
		out.println(
				"              <input type='email' name='email' id='email' class='form-control' placeholder='Customer Email'>");
		out.println("            </div>");
		out.println("          </div>");
		out.println("          <div class='form-group'>");
		out.println("            <label for='phone' class='col-sm-2 control-label'>Phone</label>");
		out.println("            <div class='col-sm-10'>");
		out.println(
				"              <input type='text' name='phone' id='phone' class='form-control' placeholder='Customer Phone'>");
		out.println("            </div>");
		out.println("          </div>");
		out.println("          ");
		out.println("          <div class='form-group'>");
		out.println("            <div class='col-sm-10 col-sm-offset-2'>");
		out.println("              <button class='btn btn-success btn-lg' type='submit'><span class='glyphicon glyphicon-floppy-disk'></span> Save</button>");
		out.println("              <button type='reset' class='btn btn-default btn-lg'><span class='glyphicon glyphicon-remove'></span> Cancel</button>");
		out.println("            </div>");
		out.println("          </div>");
		
		out.println("        </form>");
		
		out.println("      </div><!-- /.container -->");
		
		out.println("      <!-- JavaScript files before the closing body tag -->");
		out.println("      <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>");
		out.println(
				"      <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
		out.println("  </body>");
		out.println("</html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
