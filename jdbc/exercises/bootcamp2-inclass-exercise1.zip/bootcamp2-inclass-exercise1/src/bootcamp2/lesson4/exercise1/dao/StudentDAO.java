package bootcamp2.lesson4.exercise1.dao;

import java.sql.*;
import java.util.ArrayList;
import bootcamp2.lesson4.exercise1.connection.DB;
import bootcamp2.lesson4.exercise1.model.Student;


public class StudentDAO {

	public StudentDAO() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Queries database and returns all registered students in a ArrayList
	 * 
	 * @return ArrayList<Student>
	 * @throws Exception
	 */
	public ArrayList<Student> getStudents() throws Exception {

		
		/*
		 * You must finish method's body
		 */
		
		
		
	}//End of getStudents

	/**
	 * Saves student in the database
	 * 
	 * @param student, Student
	 * @throws Exception
	 */
	public void saveStudent(Student student) throws Exception {

		
		/*
		 * You must finish method's body
		 */
		
		
	}//End of saveStudent	
	
}//End of class
