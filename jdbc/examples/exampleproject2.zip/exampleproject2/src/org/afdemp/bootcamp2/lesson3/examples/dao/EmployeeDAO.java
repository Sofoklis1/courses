/**
 * 
 */
package org.afdemp.bootcamp2.lesson3.examples.dao;

import java.util.ArrayList;
import java.sql.*;

import org.afdemp.bootcamp2.lesson3.examples.connection.DB;
import org.afdemp.bootcamp2.lesson3.examples.model.Employee;

public class EmployeeDAO {

	//private Connection con = null;
	
	/**
	 * Default Constructor 
	 */
	public EmployeeDAO() {
		// TODO Auto-generated constructor stub
	}	
	
	/**
	 *  
	 * 
	 * @param surname
	 * @return
	 */
	public ArrayList<Employee> findEmployeeBySurname(String surname) throws Exception {
		
		Connection con = null;
		DB db = new DB();
		
		String sqlquery = "SELECT * FROM employee WHERE surname LIKE ?;";
		
		ArrayList<Employee> results = new ArrayList<Employee>();
		
		try {
			
			db.open(); //open connection
			con = db.getConnection(); //get Connection Object
			
			PreparedStatement stmt1 = con.prepareStatement(sqlquery);
			
			stmt1.setString(1, surname + "%");
			
			ResultSet rs = stmt1.executeQuery();

			while (rs.next()) {

				results.add(new Employee(rs.getString("afm"), rs.getString("name"), rs.getString("surname")));

			}

			rs.close();
			stmt1.close();
			db.close();

			return results;

		} catch (Exception e) {

			throw new Exception("An error occured while getting employees from database: " + e.getMessage());
			
		} finally {
			
			try {
				db.close();
			} catch (Exception e) {
				
			} 
			
		}		
		
	}	

}
